#ifndef __ASM_ARCH_GPIO_H
#define __ASM_ARCH_GPIO_H

#include <plat/gpio.h>

#endif /* __ASM_ARCH_GPIO_H */
