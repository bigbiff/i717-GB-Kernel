
#define VMALLOC_END       0xe8000000UL
