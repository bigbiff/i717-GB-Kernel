/*
 * linux/arch/arm/mach-mmp/include/mach/vmalloc.h
 */

#define VMALLOC_END	0xfe000000UL
