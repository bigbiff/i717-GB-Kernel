#ifndef __ASM_MACH_HARDWARE_H
#define __ASM_MACH_HARDWARE_H

#endif /* __ASM_MACH_HARDWARE_H */
