/*
 * linux/arch/arm/mach-mmp/include/mach/dma.h
 */

#ifndef __ASM_MACH_DMA_H
#define __ASM_MACH_DMA_H

#include <mach/addr-map.h>

#define DMAC_REGS_VIRT	(APB_VIRT_BASE + 0x00000)

#include <plat/dma.h>
#endif /* __ASM_MACH_DMA_H */
