/*
 * arch/arm/mach-ixp4xx/include/mach/vmalloc.h
 */
#define VMALLOC_END       (0xff000000UL)

