#ifndef _M32R_SIGINFO_H
#define _M32R_SIGINFO_H

#include <asm-generic/siginfo.h>

#endif /* _M32R_SIGINFO_H */
