#ifndef _ASM_M32R_SERIAL_H
#define _ASM_M32R_SERIAL_H

/* include/asm-m32r/serial.h */


#define BASE_BAUD	115200

#endif  /* _ASM_M32R_SERIAL_H */
