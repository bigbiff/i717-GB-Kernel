#ifndef _ASM_M32R_PCI_H
#define _ASM_M32R_PCI_H

#include <asm-generic/pci.h>

#endif /* _ASM_M32R_PCI_H */
