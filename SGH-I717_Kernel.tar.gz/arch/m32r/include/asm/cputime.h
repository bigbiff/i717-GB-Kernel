#ifndef __M32R_CPUTIME_H
#define __M32R_CPUTIME_H

#include <asm-generic/cputime.h>

#endif /* __M32R_CPUTIME_H */
