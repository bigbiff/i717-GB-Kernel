/* Dummy asm-offsets.c file. Required by kbuild and ready to be used - hint! */
