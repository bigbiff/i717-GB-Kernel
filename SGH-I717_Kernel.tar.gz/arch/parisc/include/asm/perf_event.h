#ifndef __ASM_PARISC_PERF_EVENT_H
#define __ASM_PARISC_PERF_EVENT_H

/* parisc only supports software events through this interface. */
static inline void set_perf_event_pending(void) { }

#endif /* __ASM_PARISC_PERF_EVENT_H */
