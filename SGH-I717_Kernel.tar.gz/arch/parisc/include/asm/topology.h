#ifndef _ASM_PARISC_TOPOLOGY_H
#define _ASM_PARISC_TOPOLOGY_H

#include <asm-generic/topology.h>

#endif /* _ASM_PARISC_TOPOLOGY_H */
