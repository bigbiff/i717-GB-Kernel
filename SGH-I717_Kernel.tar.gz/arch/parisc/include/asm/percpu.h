#ifndef _PARISC_PERCPU_H
#define _PARISC_PERCPU_H

#include <asm-generic/percpu.h>

#endif 

