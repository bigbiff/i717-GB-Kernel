#ifndef _ASMPARISC_SHMPARAM_H
#define _ASMPARISC_SHMPARAM_H

#define __ARCH_FORCE_SHMLBA 	1

#define SHMLBA 0x00400000   /* attach addr needs to be 4 Mb aligned */

#endif /* _ASMPARISC_SHMPARAM_H */
