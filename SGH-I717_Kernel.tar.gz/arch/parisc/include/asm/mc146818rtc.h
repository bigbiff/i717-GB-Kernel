/*
 * Machine dependent access functions for RTC registers.
 */
#ifndef _ASM_MC146818RTC_H
#define _ASM_MC146818RTC_H

/* empty include file to satisfy the include in genrtc.c */

#endif /* _ASM_MC146818RTC_H */
