/* This file should not exist, but lots of generic code still includes
   it. It's a hangover from old a.out days and the traditional core
   dump format.  We are ELF-only, and so are our core dumps.  If we
   need to support HP/UX core format then we'll do it here
   eventually. */
