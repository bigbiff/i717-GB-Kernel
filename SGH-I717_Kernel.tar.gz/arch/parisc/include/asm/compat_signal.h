/* Use generic */
#include <asm-generic/compat_signal.h>
