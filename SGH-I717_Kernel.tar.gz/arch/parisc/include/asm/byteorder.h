#ifndef _PARISC_BYTEORDER_H
#define _PARISC_BYTEORDER_H

#include <linux/byteorder/big_endian.h>

#endif /* _PARISC_BYTEORDER_H */
